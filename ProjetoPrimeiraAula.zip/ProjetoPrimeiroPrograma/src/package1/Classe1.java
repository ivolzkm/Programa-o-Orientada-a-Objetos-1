package package1;

public class Classe1 {private void name() {
	System.out.println();
}
}

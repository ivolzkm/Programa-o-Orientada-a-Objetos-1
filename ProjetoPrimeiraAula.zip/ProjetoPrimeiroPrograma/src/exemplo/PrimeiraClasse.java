package exemplo;

public class PrimeiraClasse {
	private String nome;
	private long cpf;
	
	public PrimeiraClasse(String nome, long cpf)
	{
		super();
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public long getCpf() {
		return cpf;
	}

	public void setCpf(long cpf) {
		this.cpf = cpf;
	}
}

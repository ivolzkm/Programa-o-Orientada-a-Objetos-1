package exemplo;

public class SegundaClasse {

}

package exemplo;

public class QuintaClasse {

}

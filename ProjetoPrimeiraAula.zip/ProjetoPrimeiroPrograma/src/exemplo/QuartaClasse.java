package exemplo;

public class QuartaClasse {

}

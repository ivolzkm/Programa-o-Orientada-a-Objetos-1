package exemplo;

public class TerceiraClasse {

}
